$(document).ready(function(){
    
$(".wp-post-image").addClass("thumb-image");

    

});

    