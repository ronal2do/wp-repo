<?php

add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size(400,400,array('center','center'));
?>
