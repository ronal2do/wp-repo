<!DOCTYPE html>
<html lang="en-US">

<head>
    <!-- Meta Tag 
        <link rel="icon" type="image/ico" href="favicon.ico" />-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    <title>
        <?php bloginfo('title'); ?>
    </title>

    <meta name="description" content="<?php bloginfo('description'); ?>" />


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css">
</head>
<body>
<!--
###############################
###############################
########     NAVBAR
###############################
###############################
-->

<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo home_url(); ?>">TechTalks</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
              <ul id="menu" class="nav navbar-nav">
       
        <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <li><a href="index.php?page_id=16">Mobile</a></li>
        <li><a href="index.php?page_id=18">Electric Vehicles</a></li>
        <li><a href="index.php?page_id=20">Science</a></li>
        <li><a href="index.php?page_id=22">Apps</a></li>
        <li class="dropdown">
          <a href="index.php?page_id=24" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Web <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>        
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
          </ul>
        </li>
      </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<script>
    var current = "<?php wp_title(); ?>";
    current = current.slice(9);
    x = document.getElementById("menu").getElementsByTagName("li");
    if( current != ""){
    for(var i = 1; i < x.length; i++){
            
            if(current == x[i].firstChild.innerHTML){
                console.log("NADJEN");
                x[i].className = "active";
            }
        }
    } else {
        console.log(x[0]);
        x[0].className = "active";
    }
    
</script>