<?php get_header(); ?>

<div class="main">
    <?php while ( have_posts() ) : the_post(); ?>
      <div class="container-fluid post">
      <h2>    <?php the_title();?>    </h2>
      <h6> Author: <?php the_author(); ?> on <?php the_Date(); ?></h6>
       <?php if ( has_post_thumbnail() ) {
        ?> 
        
        <div class="col-xs-6 col-xs-offset-3 col-md-3 col-md-offset-0"> <?php
    
    $attr = array(
    'width' => "400px",
    'height' => "400px",
	'class' =>  "img-responsive" );
	the_post_thumbnail(); ?>
	</div>
	
<?php }?>
       <div class="col-xs-12 col-md-7">
           <p> <?php the_permalink(); ?></p>
        </div>
        </div>
    <?php endwhile; ?>
</div>  

</body>
<?php get_footer(); ?>
